//
//  Sets.swift
//  newSportTimer
//
//  Created by Dmytro Gavrylov on 30.09.2022.
//

import Foundation

class Sets {
   static var sets = [SetList]()
    required init() {
        
    }
}
