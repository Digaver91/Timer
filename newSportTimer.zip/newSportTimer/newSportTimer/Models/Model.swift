//
//  Model.swift
//  newSportTimer
//
//  Created by Dmytro Gavrylov on 30.09.2022.
//

import Foundation

struct SetList {
    var setName: String
    var setTime: String
    var restTime: String
}
